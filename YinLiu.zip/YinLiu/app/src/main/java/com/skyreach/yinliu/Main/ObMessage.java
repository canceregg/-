package com.skyreach.yinliu.Main;

public class ObMessage {

    private String id;

}
