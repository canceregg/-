package com.skyreach.yinliu.Main;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.skyreach.yinliu.R;

public class minePage extends AppCompatActivity {

    private Button mbtnSocial;
    private Button mbtnMessage;
    private Button mbtnMine;
    private Button mbtnUserManage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mine_page);
        mbtnUserManage=findViewById(R.id.inforBtn);

        mbtnUserManage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(minePage.this, userManagePage.class);
                startActivity(intent);
            }
        });

    }
}
