package com.skyreach.yinliu.Main;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.skyreach.yinliu.R;

public class Ac_Test extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ac_test);
    }
}
