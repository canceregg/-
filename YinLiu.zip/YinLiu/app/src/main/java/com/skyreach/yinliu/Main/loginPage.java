package com.skyreach.yinliu.Main;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.skyreach.yinliu.R;

public class loginPage extends AppCompatActivity {

    private Button mbtnLogin;
    private Button mbtnLogon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mbtnLogon=findViewById(R.id.button2);
        mbtnLogin=findViewById(R.id.button);
        mbtnLogon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(loginPage.this, logonPage.class);
                startActivity(intent);
            }
        });
        mbtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(loginPage.this, interestPage.class);
                startActivity(intent);
            }
        });
    }

}
