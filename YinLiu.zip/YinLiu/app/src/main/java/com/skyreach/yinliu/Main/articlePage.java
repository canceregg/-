package com.skyreach.yinliu.Main;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.skyreach.yinliu.R;

public class articlePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_page);
    }
}
